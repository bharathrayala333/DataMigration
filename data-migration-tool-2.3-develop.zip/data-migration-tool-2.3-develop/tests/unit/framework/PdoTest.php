<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Migration\TestFramework;

class PdoTest extends \PDO
{
    /**
     *
     */
    public function __construct()
    {
    }
}
